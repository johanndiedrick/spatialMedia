/*
 *  simpleImage.cpp
 *  emptyExample
 *
 *  Created by Jared Schiffman on 2/2/11.
 *  Copyright 2011 Potion. All rights reserved.
 *
 */

#include "simpleImage.h"


simpleImage::simpleImage( int W, int H )
{
	width = W;
	height = H;
	image = new unsigned char [ width*height ];
	memset( image, 0, width*height*sizeof(char) );
}


bool	simpleImage::read( char* fileName )
{
	// correct the path
	char macFileName[512];
	sprintf( macFileName, "../../../data/%s", fileName );
	
	// open file
	FILE* F = fopen( macFileName, "r" );
	if ( F==NULL  )
	{
		printf("ERROR. Could not read file %s\n", macFileName );
		exit(0);
	}
	
	// read file
	fread( image, width*height, sizeof(char), F );
	
	// close file
	fclose(F);
}


bool	simpleImage::write( char* fileName )
{
	// open file
	FILE* F = fopen( fileName, "w" );
	if ( F==NULL  )
	{
		printf("ERROR. Could not write file %s\n", fileName );
		exit(0);
	}
	
	// write file
	fwrite( image, width*height, sizeof(char), F );
	
	// close file
	fclose(F);
}


void	simpleImage::draw( int posX, int posY )
{
	glRasterPos2i( posX, posY );
	glPixelZoom( 1,-1 );
	glDrawPixels( width, height, GL_LUMINANCE, GL_UNSIGNED_BYTE, image );
}


void	simpleImage::setPixel( int x, int y, int value )
{
	// test if x,y are in bounds
	if( x < 0 || x >= width || y < 0 || y >= height )
	{
		printf("ERROR. setPixel %d %d out of bounds\n", x, y );
		return;
	}
	
	// calculate the index and set the pixel
	int index = y*width + x;
	image[index] = value;
}


int		simpleImage::getPixel( int x, int y )
{
	// test if x,y are in bounds
	if( x < 0 || x >= width || y < 0 || y >= height )
	{
		printf("ERROR. getPixel %d %d out of bounds\n", x, y );
		return 0;
	}
	
	// calculate the index and return the pixel
	int index = y*width + x;
	return image[index];
}



