/*
 *  simpleImage.h
 *  emptyExample
 *
 *  Created by Jared Schiffman on 2/2/11.
 *
 */


#include "ofMain.h"

class simpleImage
{
public:
	
	simpleImage( int W, int H );
		
	bool			read( char* fileName );
	bool			write( char* fileName );
	
	void			draw( int posX, int posY );
		
	void			setPixel( int x, int y, int value );
	int				getPixel( int x, int y );
	
private:
	int				width, height;
	unsigned char*	image;
};