//  smImage.cpp
//  spatialMedia


#include <iostream>
#include "smImage.h"
#include "poSimpleDrawing.h"
#include "poApplication.h"
using namespace std;



smImage::smImage( const char* fileName, int W, int H )
{  
    // set the image width and height
    width = W;
    height = H;
    
    // load in the image data from file
    FILE* F = fopen( fileName, "rb" );                  // open a file
    if ( F==NULL )
    {
        printf("ERROR: can't find file: %s\n", fileName );
        exit(0);
    }
    imageData = new unsigned char [ width*height ];     // allocate memory for the image
    fread( imageData, 1, width*height, F );             // read file date into the memory
    fclose( F );                                        // close the file
    
    // used for fastDraw method
    imageAsTexture = new poTexture( width, height, imageData, poTextureConfig(GL_LUMINANCE) );
}

smImage::smImage( int W, int H )
{
    // set the image width and height
    width = W;
    height = H;
    
    // load in the image data from file
    imageData = new unsigned char [ width*height ];     // allocate memory for the image
    memset( imageData, 255, width*height );
    
    // used for fastDraw method
    imageAsTexture = new poTexture( width, height, imageData, poTextureConfig(GL_LUMINANCE) );
}

int     smImage::getPixel( int x, int y )
{
    int index = x + y*width;                    // calculate the pixel index
    if ( index < 0 || index >= width*height )
    {
        printf("ERROR: getPixel out of bounds\n");
        return 0;
    }
    return imageData[index];                    // return the pixel
}

void    smImage::setPixel( int x, int y, int grayValue )
{
    int index = x + y*width;                    // calculate the pixel index
    if ( index < 0 || index >= width*height )
    {
        printf("ERROR: setPixel out of bounds\n");
        return 0;
    }
    imageData[index] = grayValue;               // set the pixel
}

void    smImage::draw()
{
    // this is an inefficent, but simple mode of drawing an image
    // we draw one rectangle for every pixel
    // use the fastDraw() method if you want something faster
    for( int x=0; x<width; x++ )
    {
        for( int y=0; y<height; y++ )
        {
            float grayValue = getPixel(x,y);            // get the gray value
            grayValue = grayValue / 255;                // convert from 0-255 to 0.0-1.0
            po::setColor( poColor( grayValue, grayValue, grayValue) );  // set the color
            po::drawFilledRect( x*5,y*5, 5, 5 );        // draw the "pixel" rectangle
        }
    }
}

void    smImage::fastDraw( float x, float y )
{
    // replace the image data int the texture
    imageAsTexture->replace( imageData );
    // draw the texture
    po::drawTexturedRect( imageAsTexture, poRect(x+0,y+height,width,-height) );
}




bool smImage::somethingThere(int x0, int y0, int x1, int y1){
    
    // po::setColor(poColor(255,0,255));
    po::drawLine(poPoint(x0,y0), poPoint(x1,y0)); //top left to top right
    po::drawLine(poPoint(x1,y0), poPoint(x1,y1)); // top right to bottom right
    po::drawLine(poPoint(x0,y1), poPoint(x1,y1)); // bottom right to bottom left
    po::drawLine(poPoint(x0,y0), poPoint(x0,y1));
    
    int totalBlack=0;
    int totalWhite=0;
    
    for(int x=0; x<400; x++){
        for(int y=0; y<300; y++){
            if(smImage::getPixel(x, y) == 0) totalBlack++;
            if(smImage::getPixel(x, y) == 255) totalWhite++;
        }
    }
    cout <<  "Black: " << totalBlack << " White: " << totalWhite << " Something There?: " << isSomethingThere << "\n";
    //            if (totalWhite+totalBlack/totalWhite>.5){ 
    //                isSomethingThere=true;
    //            }
    //            else isSomethingThere=false;
    //            
    //            return isSomethingThere;
    
}














